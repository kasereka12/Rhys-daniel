//# sourceMappingURL=datatables-demo.js.map
var process=process||{env:{NODE_ENV:"development"}};$(document).ready(function(){$("#dataTable").DataTable()});